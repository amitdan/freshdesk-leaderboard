exports = {
  events: [
    { event: "onTicketUpdate", callback: "onTicketUpdateCallback" }
  ],
  onTicketUpdateCallback: function(args) {
  var names=args.username;
  console.log('******Name*******' + names);
  var status=args.status;
  console.log('******status*******' + status);
    if(status == 4 || status == 5){
	$db.get("name:status").then(function(data) {
		console.log('status' +status);
		console.log('name' +names);
		console.log('Object.keys(data) == names -' +Object.keys(data));
		
		if(names in data){
		console.log('namelist' +data[names]);
		data[names] = data[names]+1;		
		$db.set( "name:status", data).then (
			function(data) {					
				console.log('sucessfully entered'+JSON.stringify(data));
			});
		}
		else{				
		    data[names] = 1;			
			$db.set( "name:status", data).then (
			function(data) {					
				console.log('Sucessfully entered'+JSON.stringify(data));
			});
	}	
    });
  }	
	}
};