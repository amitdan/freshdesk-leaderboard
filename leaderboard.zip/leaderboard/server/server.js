exports = {
  events: [
    { event: "onTicketUpdate", callback: "onTicketUpdateCallback" }
  ],
  onTicketUpdateCallback: function(args) {
  var names=args.username;
  var status=args.status;
    if(status == 4 || status == 5){
	$db.get("NumberOfTicketsResolved").then(function(data) {		
		if(names in data){
		data[names] = data[names]+1;		
		$db.set("NumberOfTicketsResolved", data).then (
			function(data) {					
				console.log('sucessfully entered'+JSON.stringify(data));
			});
		}
		else{				
		    data[names] = 1;			
			$db.set("NumberOfTicketsResolved", data).then (
			function(data) {					
				console.log('Sucessfully entered'+JSON.stringify(data));
			});
	}	
    });
  }	
	}
};