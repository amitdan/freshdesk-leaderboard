## Freshdesk App Project

Congratulations on creating your App Project! Feel free to replace this text with your project description.

### Project folder structure explained

    .
    ├── .gitignore                 In case you decide to version this code with Git.
    ├── README.md                  This file.
    ├── app                        Source code of the app.
    │   └── template.html          HTML for the app.           
    |   └── logo.png               Image for the app.
    ├── config                     Installation parameter configs.
    │   ├── iparam_en.json         Installation parameter config in English language.
    │   └── iparam_test_data.json  Installation parameter data for local testing.
    └── manifest.json              Project manifest.
    └── server                     Business logic for remote request and event handlers.
        ├── lib
        │   └── handle-response.js
        ├── server.js
        └── test_data
            ├── onContactCreate.json
            ├── onContactUpdate.json
            ├── onConversationCreate.json
            ├── onTicketCreate.json
            └── onTicketUpdate.json

More details on the structure and files:

1. `iparam_en.json` has commented sample configuration. `_en` in the configuration refers to English language. If you need to support installation-configuration in multiple languages, say Italian in addition to English, you need to have a `iparam_it.json` configuration. English is the default fallback language.
2. `iparam_test_data.json` is the installation parameter that is used in Local Testing.
