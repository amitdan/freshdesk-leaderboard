var username_contact;
var status_ticket;

function displayNote() {
 client.data.get('contact')
  .then(function(userData) {
    client.data.get('ticket')
    .then(function(ticketData) {
	username_contact = userData.contact.name ;
     status_ticket = ticketData.ticket.status;
	client.request.invoke('onTicketUpdateCallback',{
	username:username_contact,
	status:status_ticket
	}).then(function(data) {
		$('#demo').text(data);
	})
	
	})
	})     
	
  client.db.get("NumberOfTicketsResolved")
  .then(function(data) {	  
	var tbl=$("<table/>").attr("id","mytable"); 
	$("#div1").append(tbl);
	
	var tr1="<tr>";
	var td="<td>Rank</td>";
	var td0="<td>Resource Name</td></tr>";
	$("#mytable").append(tr1+td+td0); 
	var arrayListt = new Array();
    for(var i=0;i<Object.keys(data).length;i++)
    {		
		arrayListt.push(Object.values(data)[i] + '-' +Object.keys(data)[i]);    
    } 
	
	arrayListt.sort();
	arrayListt.reverse();
	
	for(var i=0;i<arrayListt.length;i++)
    {
		
	var splitArray = arrayListt[i].split('-');

    var tr="<tr>";
    var td1="<td>"+ (i+1) +"</td>";	
    var td2="<td>"+splitArray[1]+"</td></tr>";	
     $("#mytable").append(tr+td1+td2); 

    } 
    });
}

window.addEventListener('load', function() {
  app.initialized().then(function(client) {
    window.body = $('body');
    window.client = client
    displayNote();	
  });
});